import { Button } from "@/components/ui/button";
import { Play, TrendingUp, Calendar } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative bg-gradient-hero text-white overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="w-full h-full bg-repeat" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
      </div>
      
      <div className="relative container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
            Cricket Statistics
            <span className="block text-3xl md:text-4xl mt-2 text-white/90">
              & Live Updates
            </span>
          </h1>
          
          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-white/80 mb-8 max-w-2xl mx-auto">
            Your ultimate destination for cricket scores, player stats, match highlights, and tournament coverage
          </p>
          
          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button size="lg" className="bg-white text-primary hover:bg-white/90 shadow-lg">
              <Play className="h-5 w-5 mr-2" />
              Watch Highlights
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm"
            >
              <TrendingUp className="h-5 w-5 mr-2" />
              View Statistics
            </Button>
          </div>
          
          {/* Live Match Indicator */}
          <div className="flex items-center justify-center space-x-2 text-white/70">
            <div className="h-2 w-2 bg-red-400 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium">Live matches updating</span>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 max-w-4xl mx-auto">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
            <div className="text-3xl font-bold mb-2">50K+</div>
            <div className="text-white/80">Matches Covered</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
            <div className="text-3xl font-bold mb-2">10K+</div>
            <div className="text-white/80">Players Tracked</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center">
            <div className="text-3xl font-bold mb-2">500+</div>
            <div className="text-white/80">Tournaments</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;