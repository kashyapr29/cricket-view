import Header from "@/components/Layout/Header";
import HeroSection from "@/components/HomePage/HeroSection";
import LatestMatches from "@/components/HomePage/LatestMatches";
import FeaturedPlayers from "@/components/HomePage/FeaturedPlayers";
import VideoHighlights from "@/components/HomePage/VideoHighlights";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <LatestMatches />
        <FeaturedPlayers />
        <VideoHighlights />
      </main>
    </div>
  );
};

export default Index;
